package kr.co.human.serviceimpl;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Service;

import kr.co.human.service.UserService;

@Service
public class UserServiceImpl implements UserService{

    @Override
    public boolean login(String id, String pw) {
        System.out.println("UserServiceImpl의 login메소드");
        if(id.equals("ggoomter") && pw.equals("0070")) {
            return true;
        }else {
            return false;            
        }
    }

    @Override
    public void logout(HttpSession session) {
        // TODO Auto-generated method stub
        
    }

    
    
    
}
