package kr.co.human.service;

import java.util.List;

import kr.co.human.model.BoardVO;

public interface BoardService {
    
    /*게시판 등록*/
    public void enroll(BoardVO board);
    
    /* 게시판 목록 리스트 읽기 */
    public List<BoardVO> getList();
    
    /* 게시판 하나 디테일 읽기 */
    /* 게시판 수정*/
    /* 게시판 삭제*/
    
}
