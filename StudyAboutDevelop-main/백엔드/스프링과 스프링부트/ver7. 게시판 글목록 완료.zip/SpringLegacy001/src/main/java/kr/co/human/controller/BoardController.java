package kr.co.human.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import kr.co.human.model.BoardVO;
import kr.co.human.service.BoardService;

@Controller
@RequestMapping("/board/*")
public class BoardController {
    private static final Logger log = LoggerFactory.getLogger(BoardController.class);
    
    @Autowired
    private BoardService bservice;
    
    /* 게시판 목록(리스트) 화면 */
    @GetMapping("/list")
    public void boardListGET(Model model) {
        log.debug("게시판 목록 컨트롤러 진입");
        model.addAttribute("list", bservice.getList());
    }
    
    /* 게시판 글쓰기 화면 */
    @GetMapping("/enroll")
    public void boardEnrollGET() {
        log.debug("게시판 등록 컨트롤러 진입");
        /* WEB-INF/views/board 안에 있으면 자동으로 해당이름을 가진 페이지 리턴한다.*/
    }
    
    /* 게시판 등록. 글쓰기 처리 */
    @PostMapping("/enroll")
    public String boardEnrollPOST(BoardVO board, RedirectAttributes rttr) {
        log.debug("BoardVO : " + board);
        bservice.enroll(board);
        rttr.addFlashAttribute("result", "등록 성공");  //일회성 데이터 전달
        return "redirect:/board/list";  //글쓰고 나면 자동으로 목록으로 이동
    }
}
