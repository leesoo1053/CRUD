package kr.co.human.mapper;

import java.util.List;

import kr.co.human.model.BoardVO;

public interface BoardMapper {

    public void enroll(BoardVO board);  /* 글쓰기 */
    public String getTime2();           /* 임시 테스트 */
    public List<BoardVO> getList();     /* 게시판 목록 */
}
