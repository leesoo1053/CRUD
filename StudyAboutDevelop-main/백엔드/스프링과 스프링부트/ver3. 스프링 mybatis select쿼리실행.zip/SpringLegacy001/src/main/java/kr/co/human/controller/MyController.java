package kr.co.human.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import kr.co.human.serviceimpl.UserServiceImpl;

/**
 * Handles requests for the application home page.
 */
@Controller
public class MyController {
	
	private static final Logger logger = LoggerFactory.getLogger(MyController.class);
	@Autowired
    private UserServiceImpl loginService;

	@RequestMapping(value = "/a", method = RequestMethod.GET)
	public ModelAndView home(HttpServletRequest request, HttpServletResponse response) {
        ModelAndView mv = new ModelAndView();
		mv.addObject("data1", "안녕하세요 첫번째로 만든 컨트롤러예요");
        mv.setViewName("a");
		return mv;
	}
	
   @RequestMapping(value = "/b", method = RequestMethod.GET)
    public ModelAndView goB(HttpServletRequest request, HttpServletResponse response) {
       ModelAndView mv = new ModelAndView();
       mv.addObject("data2", "안녕하세요 두번째로 만든 컨트롤러예요");
       mv.setViewName("b");
       return mv;
    }
   
   @RequestMapping(value = "/c")
   public String goC() {
      return "c";
   }
   
   
   @RequestMapping(value = "/login")
   public String login() {
      return "login";   //단순히 로그인 화면만 띄워줌
   }
   
   //로그인화면에서 데이터입력후 로그인버튼을 눌렀을때
   @RequestMapping(value = "/login", method = RequestMethod.POST)
   public ModelAndView userLogin(HttpServletRequest request, HttpServletResponse response) {
      String id = request.getParameter("userID");
      String pw = request.getParameter("userPassword");
      System.out.printf("화면에서 받아온 id : %s, pw : %s\n" ,id, pw);
      boolean result = loginService.login(id, pw);
      
      ModelAndView mv = new ModelAndView();
      mv.addObject("result", result);
      mv.setViewName("loginResult");
      return mv;
   }
	
	
}
