package kr.co.human.service;

import javax.servlet.http.HttpSession;

public interface UserService {
    
    public boolean login(String id, String pw);
    public void logout(HttpSession session);
}
