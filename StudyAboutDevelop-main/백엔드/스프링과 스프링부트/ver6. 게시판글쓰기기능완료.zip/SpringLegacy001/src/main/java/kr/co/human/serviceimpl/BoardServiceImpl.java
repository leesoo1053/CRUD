package kr.co.human.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import kr.co.human.mapper.BoardMapper;
import kr.co.human.model.BoardVO;
import kr.co.human.service.BoardService;

@Service
public class BoardServiceImpl implements BoardService{

    @Autowired
    private BoardMapper mapper;
    
    @Override
    public void enroll(BoardVO board) {
        mapper.enroll(board);
        
    }

}
