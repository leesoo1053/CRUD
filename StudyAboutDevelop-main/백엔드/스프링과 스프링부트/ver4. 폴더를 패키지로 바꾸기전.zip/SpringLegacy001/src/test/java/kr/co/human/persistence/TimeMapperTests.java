package kr.co.human.persistence;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import kr.co.human.mapper.TimeMapper;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class TimeMapperTests {

    @Autowired
    private TimeMapper timeMapper;  //인터페이스
    
    @Test
    public void testGetTime() {
        System.out.println(timeMapper.getTime());   //인터페이스의 함수
    }
    
    @Test
    public void testGetTime2() {
        System.out.println(timeMapper.getTime2());   //인터페이스의 함수
    }
    
}