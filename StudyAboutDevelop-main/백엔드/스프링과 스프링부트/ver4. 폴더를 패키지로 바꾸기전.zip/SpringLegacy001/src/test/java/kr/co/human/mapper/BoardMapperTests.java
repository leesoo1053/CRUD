package kr.co.human.mapper;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import kr.co.human.model.BoardVO;

public class BoardMapperTests {

    private static final Logger log = LoggerFactory.getLogger(BoardMapperTests.class);
    
    @Autowired
    private BoardMapper mapper;

    @Test
    public void testEnroll() {
        System.out.println("testEnroll진입");
        BoardVO vo = new BoardVO();
        
        vo.setTitle("mapper test");
        vo.setContent("mapper test");
        vo.setWriter("mapper test");
        
        System.out.println("매퍼실행전");
        mapper.enroll(vo);
        System.out.println("매퍼실행후");
        
    }
}
