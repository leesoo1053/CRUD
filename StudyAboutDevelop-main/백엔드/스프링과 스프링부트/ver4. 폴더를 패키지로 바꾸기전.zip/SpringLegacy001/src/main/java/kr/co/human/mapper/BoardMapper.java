package kr.co.human.mapper;

import kr.co.human.model.BoardVO;

public interface BoardMapper {

    public void enroll(BoardVO board);
}
